import { Component } from '@angular/core';

@Component({
  selector: 'app-pago',
  standalone: true,
  imports: [],
  templateUrl: './pago.component.html',
  styleUrl: './pago.component.css'
})
export class PagoComponent {

}
