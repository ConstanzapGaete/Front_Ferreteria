import { Component, Inject, PLATFORM_ID, OnInit } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { NavbarTrabajadorComponent } from './shared/navbar-trabajador/navbar-trabajador.component';
import { JwtHelperService } from '@auth0/angular-jwt';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NavbarComponent, CommonModule, NavbarTrabajadorComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  userName: string | null = null;
  userEmail: string | null = null;
  isLoggedIn: boolean = false;
  menuOpen: boolean = false;

  public isPublicRoute(): boolean {
    return !['/admin', '/vendedor', '/bodeguero', '/contador'].includes(this.router.url);
  }

  public isPrivateRoute(): boolean {
    return ['/admin', '/vendedor', '/bodeguero', '/contador'].includes(this.router.url);
  }

  private messages = [
    '🛻 <strong>Retiro en sucursal o envío a domicilio.</strong> ¡Tú decides!',
    '🔧 <strong>Tenemos todo lo que buscas</strong> en ferretería y construcción.',
    '💳 <strong>Compra online con múltiples medios de pago</strong> y recibe en casa.',
    '📦 <strong>Despachos a todo Chile</strong> en 24 a 72 horas.',
  ];

  currentMessage = this.messages[0];
  private index = 0;
  bannerClass = 'fade-enter';

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    public router: Router,
    private authService: AuthService
  ) {
    if (isPlatformBrowser(this.platformId)) {
      setInterval(() => {
        if (this.router.url !== '/login') {
          this.bannerClass = 'fade-enter';
          setTimeout(() => {
            this.index = (this.index + 1) % this.messages.length;
            this.currentMessage = this.messages[this.index];
            this.bannerClass = 'fade-enter-active';
          }, 100);
        }
      }, 4000);
    }
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      const token = localStorage.getItem('token');
      const jwtHelper = new JwtHelperService();

      if (token && !jwtHelper.isTokenExpired(token)) {
        const decoded: any = jwtHelper.decodeToken(token);
        this.isLoggedIn = true;
        this.userEmail = decoded.sub; // Muestra el correo como identificador
      }
    }
  }

  toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }

  logout(): void {
    this.authService.logout();
    this.isLoggedIn = false;
    this.router.navigate(['/login']);
  }

  goTo(ruta: string): void {
    this.router.navigate(['/' + ruta]);
    this.menuOpen = false;
  }
}
