export interface Comuna {
  id: number;
  nombre: string;
  regionId: number;
}