export interface Rol {
  id: number;
  nombre: string; 
}