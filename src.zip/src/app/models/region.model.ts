export interface Region {
  id: number;
  nombre: string;
}